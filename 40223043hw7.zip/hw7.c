#include <stdio.h> //KianaSharifzadeh 40223043
#include <ctype.h>
#include <string.h>
struct lang{
    char word[25];
};
int main(){
    char space[2]=" ";
    int n;
    printf("enter n");
    scanf("%d",&n);
    struct lang lang1[n];
    struct lang lang2[n];
    struct lang phr[50];

    printf("language 1: language 2:\n");

    for(int i=0;i<n ; i++){
        scanf("%s %s",lang1[i].word,lang2[i].word);
    }
    int flag;
    if(lang1[0].word[0]==tolower(lang1[0].word[0]))
       flag=1;
    else
       flag=0;

    char cleaner=getchar();
    char sent[75];
    printf("enter sentence");
    fgets(sent,sizeof(sent),stdin); //fgets

    int lenSent=strlen(sent);
    int j=0;
    int k=0;
    int phrcounter=1;

     for (int i=0; i<lenSent ;i++){
        if(sent[i]!=space[0]){
            if(flag==1){
                phr[j].word[k]=tolower(sent[i]);
                k++;
            }
            else if(flag==0){
                phr[j].word[k]=toupper(sent[i]);
            k++;
            }           
        }

        else{
            phr[j].word[k]='\0';
            j++;
            k=0;
            phrcounter++;
        }
    }
   
     for (int i = 0; i < phrcounter; i++) { //for every word in phr 
        for (int j = 0; j < n; j++) { //comparing with all words in lang1
            int match = 1;
            int lang1Len = strlen(lang1[j].word);
            for (int k = 0; k < lang1Len; k++) { //comparing letter by letter
                if (phr[i].word[k] != lang1[j].word[k]) {
                    match = 0;
                    break;  
                }
            }
            if (match) {
                if (strlen(lang2[j].word) < strlen(phr[i].word)) {
                    strcpy(phr[i].word, lang2[j].word);
                }
                break;  // Break out of the inner loop once a match is found
            }
        }
    }

    for(int i=0; i<phrcounter ; i++){
        printf("%s ", phr[i].word);
    }
    return 0;
}